# Mob Control — Fabric 1.20.1

Possess and fully control any mob in the game.

## How it works

1. **Get the Control Orb** — `/give @s mobcontrol:control_orb`
2. **Right-click any mob** with the orb to possess it
3. **Move with WASD**, look with mouse, jump with Space, attack with Left Click
4. **Press R** to release possession

## What happens during possession

- The mob's AI is disabled — you drive it entirely
- The mob is made temporarily invulnerable (so it doesn't take passive damage while you control it)
- Your player is teleported to the mob's position each tick to avoid flying kicks
- Camera follows your player (who is co-located with the mob)
- Left-click attacks the nearest entity within 3 blocks in your look direction
- If the mob dies (e.g. falls in lava), possession is automatically released

## Build

Requires JDK 17 and Fabric toolchain.

```bash
./gradlew build
```

Output jar: `build/libs/mob-control-1.0.0.jar`

Put the jar in your `.minecraft/mods/` folder alongside Fabric API.

## Dependencies

- Fabric Loader 0.15.7+
- Fabric API 0.92.0+1.20.1
- Minecraft 1.20.1

## Notes

- The `ServerPlayNetworkHandlerMixin` cancels movement validation while possessing to prevent false-positive fly kicks. This is safe — movement is validated through the mob entity instead.
- The mod works in multiplayer. Each player can possess one mob at a time.
- Bosses (Wither, Ender Dragon) can be possessed — use wisely.

package com.mobcontrol.item;

import com.mobcontrol.MobControlMod;
import com.mobcontrol.PossessionState;
import com.mobcontrol.network.MobControlPackets;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

public class ControlOrbItem extends Item {

    public ControlOrbItem(Settings settings) {
        super(settings);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        // Not used — we use useOnEntity
        return TypedActionResult.pass(user.getStackInHand(hand));
    }

    @Override
    public ActionResult useOnEntity(ItemStack stack, PlayerEntity user, LivingEntity entity, Hand hand) {
        if (world(user).isClient) {
            // Client side: do nothing, let server handle
            return ActionResult.SUCCESS;
        }

        if (!(user instanceof ServerPlayerEntity player)) return ActionResult.PASS;
        if (!(entity instanceof MobEntity mob)) {
            player.sendMessage(Text.literal("§cYou can only possess mobs."), true);
            return ActionResult.FAIL;
        }

        if (PossessionState.isPossessing(player)) {
            player.sendMessage(Text.literal("§eYou are already possessing a mob. Press [R] to release first."), true);
            return ActionResult.FAIL;
        }

        PossessionState.possess(player, mob);

        // Tell client to enter possession mode
        ServerPlayNetworking.send(player, MobControlPackets.POSSESSION_START_PACKET, PacketByteBufs.empty());

        player.sendMessage(Text.literal("§aPossessing " + mob.getType().getName().getString() + "!"), true);
        return ActionResult.SUCCESS;
    }

    private World world(PlayerEntity user) {
        return user.getWorld();
    }
}

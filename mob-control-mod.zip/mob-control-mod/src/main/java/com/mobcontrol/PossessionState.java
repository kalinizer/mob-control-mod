package com.mobcontrol;

import net.minecraft.entity.mob.MobEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.math.Vec3d;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class PossessionState {

    // Maps player UUID -> possessed mob
    private static final Map<UUID, MobEntity> POSSESSED = new HashMap<>();

    public static void possess(ServerPlayerEntity player, MobEntity mob) {
        // Release any existing possession first
        release(player);

        POSSESSED.put(player.getUuid(), mob);

        // Store original mob AI state via NBT tag approach — disable mob AI
        mob.setAiDisabled(true);
        mob.setInvulnerable(true);

        MobControlMod.LOGGER.info("{} is now possessing {}", player.getName().getString(), mob.getType().toString());
    }

    public static void release(ServerPlayerEntity player) {
        MobEntity mob = POSSESSED.remove(player.getUuid());
        if (mob != null && mob.isAlive()) {
            mob.setAiDisabled(false);
            mob.setInvulnerable(false);
        }
    }

    public static MobEntity getPossessed(ServerPlayerEntity player) {
        return POSSESSED.get(player.getUuid());
    }

    public static boolean isPossessing(ServerPlayerEntity player) {
        MobEntity mob = POSSESSED.get(player.getUuid());
        if (mob != null && !mob.isAlive()) {
            // Mob died — clean up
            POSSESSED.remove(player.getUuid());
            return false;
        }
        return mob != null;
    }

    /**
     * Move the possessed mob based on player input direction.
     * Called each tick from server-side packet handler.
     */
    public static void applyMovement(ServerPlayerEntity player, float forward, float sideways, float yaw, float pitch, boolean jump, boolean attack) {
        MobEntity mob = POSSESSED.get(player.getUuid());
        if (mob == null || !mob.isAlive()) {
            release(player);
            return;
        }

        // Sync rotation
        mob.setYaw(yaw);
        mob.setPitch(pitch);
        mob.setHeadYaw(yaw);
        mob.setBodyYaw(yaw);

        // Compute velocity from input
        double speed = 0.2;
        double radYaw = Math.toRadians(yaw);

        double dx = 0;
        double dz = 0;

        if (forward != 0 || sideways != 0) {
            // Forward direction based on yaw
            dx += -Math.sin(radYaw) * forward * speed;
            dz += Math.cos(radYaw) * forward * speed;
            // Strafe
            dx += Math.cos(radYaw) * sideways * speed;
            dz += Math.sin(radYaw) * sideways * speed;
        }

        Vec3d currentVel = mob.getVelocity();
        double dy = currentVel.y;

        if (jump && mob.isOnGround()) {
            dy = 0.42;
        }

        mob.setVelocity(dx, dy, dz);
        mob.velocityModified = true;

        // Attack — swing arm and hit nearest entity in look direction
        if (attack) {
            mob.swingHand(net.minecraft.util.Hand.MAIN_HAND);
            // Find entity in front of mob within 3 blocks
            Vec3d start = mob.getEyePos();
            Vec3d end = start.add(mob.getRotationVector().multiply(3.0));
            mob.getWorld().getOtherEntities(mob, mob.getBoundingBox().stretch(mob.getRotationVector().multiply(3.0)).expand(1.0))
                    .stream()
                    .filter(e -> e != player)
                    .min((a, b) -> Double.compare(a.squaredDistanceTo(mob), b.squaredDistanceTo(mob)))
                    .ifPresent(target -> {
                        mob.tryAttack(target);
                    });
        }

        // Keep player position synced near mob so they don't get kicked for flying
        player.teleport(mob.getX(), mob.getY(), mob.getZ());
    }
}

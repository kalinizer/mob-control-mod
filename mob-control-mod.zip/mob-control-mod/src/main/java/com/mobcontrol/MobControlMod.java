package com.mobcontrol;

import com.mobcontrol.item.ControlOrbItem;
import com.mobcontrol.network.MobControlPackets;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MobControlMod implements ModInitializer {
    public static final String MOD_ID = "mobcontrol";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static final Item CONTROL_ORB = new ControlOrbItem(new FabricItemSettings().maxCount(1));

    @Override
    public void onInitialize() {
        Registry.register(Registries.ITEM, new Identifier(MOD_ID, "control_orb"), CONTROL_ORB);
        MobControlPackets.registerServerPackets();
        LOGGER.info("Mob Control initialized.");
    }
}

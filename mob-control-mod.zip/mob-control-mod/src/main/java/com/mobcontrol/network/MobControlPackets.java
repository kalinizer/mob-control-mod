package com.mobcontrol.network;

import com.mobcontrol.MobControlClient;
import com.mobcontrol.MobControlMod;
import com.mobcontrol.PossessionState;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.PacketSender;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayNetworkHandler;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Identifier;

public class MobControlPackets {

    // Client -> Server
    public static final Identifier MOVEMENT_PACKET = new Identifier(MobControlMod.MOD_ID, "movement");
    public static final Identifier RELEASE_MOB_PACKET = new Identifier(MobControlMod.MOD_ID, "release");

    // Server -> Client
    public static final Identifier POSSESSION_START_PACKET = new Identifier(MobControlMod.MOD_ID, "possession_start");
    public static final Identifier POSSESSION_END_PACKET = new Identifier(MobControlMod.MOD_ID, "possession_end");

    public static void registerServerPackets() {
        // Receive movement from client
        ServerPlayNetworking.registerGlobalReceiver(MOVEMENT_PACKET, MobControlPackets::handleMovement);

        // Receive release request from client
        ServerPlayNetworking.registerGlobalReceiver(RELEASE_MOB_PACKET, (server, player, handler, buf, responseSender) -> {
            server.execute(() -> {
                if (PossessionState.isPossessing(player)) {
                    PossessionState.release(player);
                    // Notify client
                    ServerPlayNetworking.send(player, POSSESSION_END_PACKET, PacketByteBufs.empty());
                }
            });
        });
    }

    private static void handleMovement(MinecraftServer server, ServerPlayerEntity player,
                                       ServerPlayNetworkHandler handler, PacketByteBuf buf, PacketSender sender) {
        float forward   = buf.readFloat();
        float sideways  = buf.readFloat();
        float yaw       = buf.readFloat();
        float pitch     = buf.readFloat();
        boolean jump    = buf.readBoolean();
        boolean attack  = buf.readBoolean();

        server.execute(() -> {
            if (PossessionState.isPossessing(player)) {
                PossessionState.applyMovement(player, forward, sideways, yaw, pitch, jump, attack);
            }
        });
    }

    public static void registerClientPackets() {
        // Server tells us possession started
        ClientPlayNetworking.registerGlobalReceiver(POSSESSION_START_PACKET, (client, handler, buf, responseSender) -> {
            client.execute(() -> {
                MobControlClient.isPossessing = true;
                if (client.player != null) {
                    client.player.sendMessage(net.minecraft.text.Text.literal("§aPossession active! Press [R] to release."), true);
                }
            });
        });

        // Server tells us possession ended
        ClientPlayNetworking.registerGlobalReceiver(POSSESSION_END_PACKET, (client, handler, buf, responseSender) -> {
            client.execute(() -> {
                MobControlClient.isPossessing = false;
                if (client.player != null) {
                    client.player.sendMessage(net.minecraft.text.Text.literal("§cPossession released."), true);
                }
            });
        });
    }

    /**
     * Send movement data from client to server each tick.
     */
    public static void sendMovement(float forward, float sideways, float yaw, float pitch, boolean jump, boolean attack) {
        PacketByteBuf buf = PacketByteBufs.create();
        buf.writeFloat(forward);
        buf.writeFloat(sideways);
        buf.writeFloat(yaw);
        buf.writeFloat(pitch);
        buf.writeBoolean(jump);
        buf.writeBoolean(attack);
        ClientPlayNetworking.send(MOVEMENT_PACKET, buf);
    }
}

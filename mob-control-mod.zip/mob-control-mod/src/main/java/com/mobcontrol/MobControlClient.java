package com.mobcontrol;

import com.mobcontrol.network.MobControlPackets;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class MobControlClient implements ClientModInitializer {

    public static KeyBinding RELEASE_KEY;
    // Track if we're currently possessing
    public static boolean isPossessing = false;

    @Override
    public void onInitializeClient() {
        RELEASE_KEY = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.mobcontrol.release",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_R,
                "category.mobcontrol"
        ));

        MobControlPackets.registerClientPackets();

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (RELEASE_KEY.wasPressed() && isPossessing) {
                ClientPlayNetworking.send(MobControlPackets.RELEASE_MOB_PACKET, PacketByteBufs.empty());
            }
        });
    }
}

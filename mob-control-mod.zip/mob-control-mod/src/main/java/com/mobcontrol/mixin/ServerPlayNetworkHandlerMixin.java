package com.mobcontrol.mixin;

import com.mobcontrol.PossessionState;
import net.minecraft.server.network.ServerPlayNetworkHandler;
import net.minecraft.server.network.ServerPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ServerPlayNetworkHandler.class)
public class ServerPlayNetworkHandlerMixin {

    @Shadow public ServerPlayerEntity player;

    /**
     * Suppress the flying/movement violation check while a player is possessing a mob.
     * The player entity is being teleported to the mob each tick, which can trigger false positives.
     */
    @Inject(method = "onPlayerMove", at = @At("HEAD"), cancellable = true)
    private void suppressMovementCheck(net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket packet, CallbackInfo ci) {
        if (PossessionState.isPossessing(player)) {
            // Accept the packet but don't validate movement — the mob handles actual position
            ci.cancel();
        }
    }
}

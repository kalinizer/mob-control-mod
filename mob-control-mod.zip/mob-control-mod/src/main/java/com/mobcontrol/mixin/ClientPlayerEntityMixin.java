package com.mobcontrol.mixin;

import com.mobcontrol.MobControlClient;
import com.mobcontrol.network.MobControlPackets;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.input.Input;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayerEntity.class)
public class ClientPlayerEntityMixin {

    @Shadow public Input input;

    private boolean wasAttacking = false;

    @Inject(method = "tick", at = @At("TAIL"))
    private void onTick(CallbackInfo ci) {
        if (!MobControlClient.isPossessing) return;

        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) return;

        float forward   = input.movementForward;
        float sideways  = input.movementSideways;
        float yaw       = client.player.getYaw();
        float pitch     = client.player.getPitch();
        boolean jump    = input.jumping;
        boolean attack  = client.options.attackKey.isPressed();

        // Only send attack once per press
        boolean sendAttack = attack && !wasAttacking;
        wasAttacking = attack;

        MobControlPackets.sendMovement(forward, sideways, yaw, pitch, jump, sendAttack);
    }
}

package com.mobcontrol.mixin;

import com.mobcontrol.MobControlClient;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.world.BlockView;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Redirects the camera entity to the possessed mob so the player sees from the mob's POV.
 * We swap MinecraftClient.cameraEntity before the frame renders and restore it after.
 */
@Mixin(GameRenderer.class)
public class GameRendererMixin {

    @Shadow @Final private MinecraftClient client;

    private Entity originalCamera = null;

    @Inject(method = "renderWorld", at = @At("HEAD"))
    private void beforeRender(float tickDelta, long limitTime, org.joml.Matrix4f matrix, CallbackInfo ci) {
        if (!MobControlClient.isPossessing || client.player == null) return;

        // The possessed mob is where the server is teleporting the player to,
        // so the camera tracks the player — which is already at the mob's position.
        // Nothing extra needed here unless we want 3rd person from mob's body.
        // Left as hook for future use.
    }
}

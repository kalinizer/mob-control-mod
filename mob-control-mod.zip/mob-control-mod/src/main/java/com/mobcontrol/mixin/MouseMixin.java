package com.mobcontrol.mixin;

import com.mobcontrol.MobControlClient;
import net.minecraft.client.Mouse;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Mouse.class)
public class MouseMixin {
    // Mouse look still updates player yaw/pitch normally — we read those and forward to the mob.
    // Nothing to suppress; the player's look direction IS the mob's look direction.
    // This mixin is reserved for future use (e.g. locking cursor differently).
}

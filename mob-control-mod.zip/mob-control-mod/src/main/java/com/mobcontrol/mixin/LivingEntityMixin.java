package com.mobcontrol.mixin;

import com.mobcontrol.PossessionState;
import com.mobcontrol.network.MobControlPackets;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(LivingEntity.class)
public class LivingEntityMixin {

    @Inject(method = "onDeath", at = @At("HEAD"))
    private void onDeath(DamageSource source, CallbackInfo ci) {
        LivingEntity self = (LivingEntity)(Object)this;
        if (!(self instanceof MobEntity mob)) return;

        World world = mob.getWorld();
        if (world.isClient) return;

        MinecraftServer server = world.getServer();
        if (server == null) return;

        // Check all players — release if any was possessing this mob
        for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
            if (PossessionState.getPossessed(player) == mob) {
                PossessionState.release(player);
                ServerPlayNetworking.send(player, MobControlPackets.POSSESSION_END_PACKET, PacketByteBufs.empty());
                player.sendMessage(net.minecraft.text.Text.literal("§cYour mob has died. Possession released."), true);
            }
        }
    }
}

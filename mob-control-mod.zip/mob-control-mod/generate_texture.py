"""
Generates a simple 16x16 purple orb texture for the Control Orb item.
Run this once to produce control_orb.png
"""
import struct, zlib, math

def png_chunk(chunk_type, data):
    c = chunk_type + data
    return struct.pack('>I', len(data)) + c + struct.pack('>I', zlib.crc32(c) & 0xFFFFFFFF)

def create_orb_png(path):
    width, height = 16, 16
    cx, cy = 7.5, 7.5
    radius = 6.5

    rows = []
    for y in range(height):
        row = []
        for x in range(width):
            dx = x - cx
            dy = y - cy
            dist = math.sqrt(dx*dx + dy*dy)
            if dist <= radius:
                # Purple core with shine
                t = dist / radius
                # Highlight in top-left
                shine = max(0, 1 - math.sqrt((dx+2)**2 + (dy+2)**2) / 3)
                r = int(min(255, 80  + shine*180))
                g = int(min(255, 0   + shine*80))
                b = int(min(255, 200 + shine*55))
                a = 255
                # Darken edges
                edge = 1 - t**2
                r = int(r * edge)
                g = int(g * edge)
                b = int(b * 0.5 + 100 * edge)
            else:
                r, g, b, a = 0, 0, 0, 0  # transparent

            row += [r, g, b, a]
        rows.append(row)

    raw = b''
    for row in rows:
        raw += b'\x00' + bytes(row)  # filter type 0

    compressed = zlib.compress(raw, 9)

    sig = b'\x89PNG\r\n\x1a\n'
    ihdr_data = struct.pack('>IIBBBBB', width, height, 8, 2, 0, 0, 0)
    # RGBA = color type 6
    ihdr_data = struct.pack('>II', width, height) + bytes([8, 6, 0, 0, 0])

    chunks = (
        sig +
        png_chunk(b'IHDR', ihdr_data) +
        png_chunk(b'IDAT', compressed) +
        png_chunk(b'IEND', b'')
    )

    with open(path, 'wb') as f:
        f.write(chunks)
    print(f"Written: {path}")

if __name__ == '__main__':
    import os
    out = os.path.join(os.path.dirname(__file__),
        'src/main/resources/assets/mobcontrol/textures/item/control_orb.png')
    create_orb_png(out)
